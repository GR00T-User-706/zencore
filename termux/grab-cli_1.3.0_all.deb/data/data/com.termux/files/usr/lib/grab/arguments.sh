grab_main() {
  local type=generic url='' output='' filename='' quiet=0 verbose=0 dry=0 overwrite=0 force_direct=0 op='download' arg endopts=0 type_seen=0 storage=''
  config_load || return 78
  log_init
  while (($#)); do
    arg="$1"; shift
    if (( ! endopts )); then
      case "$arg" in
        --) endopts=1; continue;;
        --help|-h) print_help; return 0;;
        --version) cat "${LIB_DIR%/lib/grab}/VERSION" 2>/dev/null || printf '1.2.0\n'; return 0;;
        --check) op=check; continue;;
        --logs) op=logs; continue;;
        --errors) op=errors; continue;;
        --clear-logs) op=clear-logs; continue;;
        --config) op=config-edit; continue;;
        --config-show) op=config; continue;;
        --list-types) op=types; continue;;
        --list-destinations) op=destinations; continue;;
        --storage)
          (($#)) || { printf 'grab: --storage requires internal, sdcard, or termux\n' >&2; return 2; }
          storage="$1"; shift; continue;;
        --internal-storage|--internal) storage=internal; continue;;
        --sdcard|--sd) storage=sdcard; continue;;
        --termux-storage|--termux) storage=termux; continue;;
        --video|--audio|--image|--document|--page|--site|--script|--archive|--generic)
          (( type_seen == 0 )) || { printf 'grab: conflicting or repeated type flags\n' >&2; return 2; }
          type="${arg#--}"; type_seen=1; continue;;
        --output|-o) (($#)) || { printf 'grab: %s requires a directory\n' "$arg" >&2; return 2; }; output="$1"; shift; continue;;
        --filename|-f) (($#)) || { printf 'grab: %s requires a filename\n' "$arg" >&2; return 2; }; filename="$1"; shift; continue;;
        --type|-t) (($#)) || { printf 'grab: %s requires a type\n' "$arg" >&2; return 2; }; type="$1"; type_seen=1; shift; continue;;
        --quiet|-q) quiet=1; continue;;
        --verbose|-v) verbose=1; continue;;
        --dry-run) dry=1; continue;;
        --overwrite) overwrite=1; continue;;
        --force-direct) force_direct=1; continue;;
        -*) printf 'grab: unknown option: %s\nUse --help for usage.\n' "$arg" >&2; return 2;;
      esac
    fi
    if [[ -z "$url" ]]; then url="$arg"; else printf 'grab: unexpected extra argument: %s\n' "$arg" >&2; return 2; fi
  done

  case "$op" in
    check) check_environment; return $?;;
    logs) show_logs all; return $?;;
    errors) show_logs errors; return $?;;
    clear-logs) clear_logs; return $?;;
    config) config_show; return $?;;
    config-edit) config_edit; return $?;;
    types) print_types; return $?;;
    destinations) list_destinations; return $?;;
  esac

  [[ -n "$url" ]] || { printf 'grab: missing URL\nUse --help for usage.\n' >&2; return 2; }
  case "$type" in generic|video|audio|image|document|page|site|script|archive) ;; *) printf 'grab: unsupported type: %s\n' "$type" >&2; return 2;; esac
  case "$storage" in ''|primary|internal|sdcard|termux) ;; *) printf 'grab: unsupported storage: %s\n' "$storage" >&2; return 2;; esac
  validate_url "$url" || return 2
  if (( verbose && quiet )); then printf 'grab: --quiet and --verbose cannot be combined\n' >&2; return 2; fi
  if (( force_direct )) && [[ "$type" != video && "$type" != audio ]]; then
    printf 'grab: --force-direct requires --video or --audio\n' >&2
    return 2
  fi

  if [[ -n "$storage" ]]; then GRAB_STORAGE_DEFAULT="$storage"; fi
  if [[ -n "$output" ]]; then
    [[ "$output" == /* ]] || output="$PWD/$output"
  else
    output=$(destination_for_type "$type") || { printf 'grab: cannot resolve destination for storage %s\n' "$GRAB_STORAGE_DEFAULT" >&2; return 73; }
  fi

  if [[ -n "$filename" ]]; then
    validate_name "$filename" || { printf 'grab: filename must be a single safe path component\n' >&2; return 2; }
  fi
  if (( overwrite )) && [[ -z "$filename" ]]; then printf 'grab: --overwrite requires --filename\n' >&2; return 2; fi
  if (( overwrite )) && [[ -e "$output/$filename" ]]; then
    printf 'grab: explicit overwrite requested for %s\n' "$output/$filename" >&2
    GRAB_OVERWRITE_TARGET="$output/$filename"
  else
    GRAB_OVERWRITE_TARGET=''
  fi

  local rc=0
  GRAB_QUIET="$quiet"
  case "$type" in
    site) handle_site_mirror "$url" "$output" "$dry" || rc=$?;;
    video|audio) handle_media "$type" "$url" "$output" "$filename" "$dry" "$verbose" "$force_direct" || rc=$?;;
    page|generic|image|document|script|archive) download_generic "$url" "$type" "$output" "$filename" "$dry" "$verbose" || rc=$?;;
  esac
  return "$rc"
}
