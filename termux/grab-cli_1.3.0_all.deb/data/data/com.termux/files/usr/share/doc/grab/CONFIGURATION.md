# Configuration

GRAB uses a plain, human-editable key=value configuration file at `~/.config/grab/grab.conf`. Run `grab --config` to create it when missing and open it in `$EDITOR`; use `grab --config-show` to inspect the effective values.

Android internal storage is the primary storage root:

- Internal: `/storage/emulated/0`
- microSD: `/storage/0189-0080` by default
- Termux private storage: `$HOME`

The microSD mount name is configurable because Android volume identifiers can change when storage hardware changes. The default storage is selected with `storage.default=primary`.

Example:

```ini
[storage]
primary=/storage/emulated/0
sdcard=/storage/0189-0080
termux=$HOME
default=primary

[destination]
generic=Download
video=Movies
script=Download/Scripts
```

Destination values are relative to the selected storage root unless they are absolute paths. `--output` always wins over configured destinations.

CLI storage selection:

```bash
grab --storage internal URL
grab --storage sdcard URL
grab --storage termux URL
grab --internal-storage URL
grab --sdcard URL
grab --termux-storage URL
```

CLI options override user configuration, which overrides built-in defaults.

GRAB optionally uses Android's `termux-notification` command for useful completion/failure notifications. Notifications are best-effort and never required for downloads to work.
