CONFIG_FILE="${GRAB_CONFIG_FILE:-${XDG_CONFIG_HOME:-$HOME/.config}/grab/grab.conf}"

config_defaults() {
  GRAB_STORAGE_PRIMARY="/storage/emulated/0"
  GRAB_STORAGE_SDCARD=""
  GRAB_STORAGE_TERMUX="$HOME"
  GRAB_STORAGE_DEFAULT="primary"

  GRAB_DEFAULT_DIR="Download"
  GRAB_DEST_VIDEO="Movies"
  GRAB_DEST_AUDIO="Music"
  GRAB_DEST_IMAGE="Pictures"
  GRAB_DEST_DOCUMENT="Documents"
  GRAB_DEST_PAGE="Download/Pages"
  GRAB_DEST_SITE="Download/Sites"
  GRAB_DEST_SCRIPT="Download/Scripts"
  GRAB_DEST_ARCHIVE="Download/Archives"

  GRAB_CONNECT_TIMEOUT=20
  GRAB_TIMEOUT=600
  GRAB_RETRIES=2
  GRAB_RETRY_DELAY=2
  GRAB_MAX_RETRY_DELAY=20
  GRAB_USER_AGENT='grab (Termux; curl)'
  GRAB_COLLISION_POLICY=unique
  GRAB_LOG_DIR="${XDG_STATE_HOME:-$HOME/.local/state}/grab/logs"
  GRAB_LOG_MAX_BYTES=1048576
  GRAB_LOG_LINES=100
  GRAB_MIRROR_DEPTH=2
  GRAB_MIRROR_RATE=1
  GRAB_MIRROR_DOMAINS=
  GRAB_YTDLP_PATH=yt-dlp
  GRAB_FFMPEG_PATH=ffmpeg
  GRAB_WGET_PATH=wget
  GRAB_CONFIG_LOADED=0
}

_config_trim() {
  local v="$1"
  v="${v#"${v%%[![:space:]]*}"}"
  v="${v%"${v##*[![:space:]]}"}"
  printf '%s' "$v"
}

_config_unquote_expand() {
  local v="$(_config_trim "$1")"
  [[ "$v" == \"*\" && "$v" == *\" ]] && v="${v:1:${#v}-2}"
  [[ "$v" == \'*\' && "$v" == *\' ]] && v="${v:1:${#v}-2}"
  v="${v//\$HOME/$HOME}"
  v="${v//\$\{HOME\}/$HOME}"
  [[ "$v" == ~/* ]] && v="$HOME/${v#~/}"
  printf '%s' "$v"
}

_config_apply_key() {
  local key="$1" val="$2" section="$3" full
  val="$(_config_unquote_expand "$val")"
  full="$key"
  [[ -n "$section" ]] && full="${section}.${key}"
  case "$full" in
    storage.primary|storage.internal) GRAB_STORAGE_PRIMARY="$val";;
    storage.sdcard) GRAB_STORAGE_SDCARD="$val";;
    storage.termux) GRAB_STORAGE_TERMUX="$val";;
    storage.default) GRAB_STORAGE_DEFAULT="$val";;
    destination.generic) GRAB_DEFAULT_DIR="$val";;
    destination.video) GRAB_DEST_VIDEO="$val";;
    destination.audio) GRAB_DEST_AUDIO="$val";;
    destination.image) GRAB_DEST_IMAGE="$val";;
    destination.document) GRAB_DEST_DOCUMENT="$val";;
    destination.page) GRAB_DEST_PAGE="$val";;
    destination.site) GRAB_DEST_SITE="$val";;
    destination.script) GRAB_DEST_SCRIPT="$val";;
    destination.archive) GRAB_DEST_ARCHIVE="$val";;
    timeout.connect) GRAB_CONNECT_TIMEOUT="$val";;
    timeout.total) GRAB_TIMEOUT="$val";;
    retry.count) GRAB_RETRIES="$val";;
    retry.delay) GRAB_RETRY_DELAY="$val";;
    retry.max_delay) GRAB_MAX_RETRY_DELAY="$val";;
    user_agent) GRAB_USER_AGENT="$val";;
    collision_policy) GRAB_COLLISION_POLICY="$val";;
    logs.directory) GRAB_LOG_DIR="$val";;
    logs.max_bytes) GRAB_LOG_MAX_BYTES="$val";;
    logs.lines) GRAB_LOG_LINES="$val";;
    mirror.depth) GRAB_MIRROR_DEPTH="$val";;
    mirror.rate) GRAB_MIRROR_RATE="$val";;
    mirror.domains) GRAB_MIRROR_DOMAINS="$val";;
    tools.ytdlp) GRAB_YTDLP_PATH="$val";;
    tools.ffmpeg) GRAB_FFMPEG_PATH="$val";;
    tools.wget) GRAB_WGET_PATH="$val";;
    *) printf 'grab: ignoring unknown config key: %s\n' "$full" >&2;;
  esac
}

config_parse_file() {
  local line key val section='' lineno=0
  while IFS= read -r line || [[ -n "$line" ]]; do
    ((lineno++))
    line="$(_config_trim "$line")"
    [[ -z "$line" || "$line" == #* || "$line" == ;* ]] && continue
    if [[ "$line" =~ ^\[([a-zA-Z0-9_.-]+)\]$ ]]; then
      section="${BASH_REMATCH[1]}"
      continue
    fi
    if [[ "$line" =~ ^([a-zA-Z0-9_.-]+)[[:space:]]*=[[:space:]]*(.*)$ ]]; then
      key="${BASH_REMATCH[1]}"
      val="${BASH_REMATCH[2]}"
      _config_apply_key "$key" "$val" "$section"
    else
      printf 'grab: invalid config line %s:%s\n' "$CONFIG_FILE" "$lineno" >&2
      return 2
    fi
  done < "$CONFIG_FILE"
}

config_validate() {
  local key val d
  for key in GRAB_CONNECT_TIMEOUT GRAB_TIMEOUT GRAB_RETRIES GRAB_RETRY_DELAY GRAB_MAX_RETRY_DELAY GRAB_LOG_MAX_BYTES GRAB_LOG_LINES GRAB_MIRROR_DEPTH GRAB_MIRROR_RATE; do
    val="${!key}"
    is_uint "$val" || { printf 'grab: invalid config value %s=%s\n' "$key" "$val" >&2; return 2; }
  done
  (( GRAB_CONNECT_TIMEOUT > 0 && GRAB_TIMEOUT > 0 && GRAB_RETRIES <= 10 && GRAB_MIRROR_DEPTH <= 10 && GRAB_MIRROR_RATE > 0 )) || {
    printf 'grab: config numeric value out of range\n' >&2
    return 2
  }
  [[ "$GRAB_COLLISION_POLICY" == unique || "$GRAB_COLLISION_POLICY" == fail ]] || {
    printf 'grab: GRAB_COLLISION_POLICY must be unique or fail\n' >&2
    return 2
  }
  case "$GRAB_STORAGE_DEFAULT" in primary|internal|sdcard|termux) ;; *)
    printf 'grab: storage.default must be primary, internal, sdcard, or termux\n' >&2; return 2;;
  esac
  for d in "$GRAB_STORAGE_PRIMARY" "$GRAB_STORAGE_TERMUX" "$GRAB_LOG_DIR"; do
    [[ "$d" == /* ]] || { printf 'grab: configured root must be absolute: %s\n' "$d" >&2; return 2; }
  done
  [[ -z "$GRAB_STORAGE_SDCARD" || "$GRAB_STORAGE_SDCARD" == /* ]] || {
    printf 'grab: configured microSD root must be absolute or blank: %s\n' "$GRAB_STORAGE_SDCARD" >&2
    return 2
  }
  if [[ "$GRAB_STORAGE_DEFAULT" == sdcard && -z "$GRAB_STORAGE_SDCARD" ]]; then
    printf 'grab: storage.default=sdcard requires storage.sdcard to be configured\n' >&2
    return 2
  fi
  for d in "$GRAB_DEFAULT_DIR" "$GRAB_DEST_VIDEO" "$GRAB_DEST_AUDIO" "$GRAB_DEST_IMAGE" "$GRAB_DEST_DOCUMENT" "$GRAB_DEST_PAGE" "$GRAB_DEST_SITE" "$GRAB_DEST_SCRIPT" "$GRAB_DEST_ARCHIVE"; do
    [[ "$d" != *$'\n'* && "$d" != *$'\r'* ]] || { printf 'grab: invalid destination: %s\n' "$d" >&2; return 2; }
  done
}

config_load() {
  config_defaults
  if [[ -f "$CONFIG_FILE" ]]; then
    config_parse_file || return $?
    GRAB_CONFIG_LOADED=1
  fi
  config_validate
}

config_storage_root() {
  case "${1:-$GRAB_STORAGE_DEFAULT}" in
    primary|internal) printf '%s' "$GRAB_STORAGE_PRIMARY";;
    sdcard) printf '%s' "$GRAB_STORAGE_SDCARD";;
    termux) printf '%s' "$GRAB_STORAGE_TERMUX";;
    *) return 2;;
  esac
}

config_write_default() {
  [[ -f "$CONFIG_FILE" ]] && return 0
  mkdir -p -- "$(dirname -- "$CONFIG_FILE")" || return 1
  cat > "$CONFIG_FILE" <<'EOF_CONFIG'
# GRAB configuration. Plain key=value format.
# Android internal storage is the primary destination.
# Paths may use $HOME.

[storage]
primary=/storage/emulated/0
sdcard=
termux=$HOME
default=primary

[destination]
generic=Download
video=Movies
audio=Music
image=Pictures
document=Documents
page=Download/Pages
site=Download/Sites
script=Download/Scripts
archive=Download/Archives

[timeout]
connect=20
total=600

[retry]
count=2
delay=2
max_delay=20

[user]
user_agent=grab (Termux; curl)
collision_policy=unique

[logs]
directory=$HOME/.local/state/grab/logs
max_bytes=1048576
lines=100

[mirror]
depth=2
rate=1
domains=

[tools]
ytdlp=yt-dlp
ffmpeg=ffmpeg
wget=wget
EOF_CONFIG
}

config_edit() {
  config_write_default || { printf 'grab: cannot create configuration file: %s\n' "$CONFIG_FILE" >&2; return 1; }
  local editor="${EDITOR:-${VISUAL:-nano}}"
  if command -v "$editor" >/dev/null 2>&1 && [[ -t 0 && -t 1 ]]; then
    "$editor" "$CONFIG_FILE"
  else
    printf 'Configuration file: %s\n' "$CONFIG_FILE"
    printf 'Edit with: %s %q\n' "$editor" "$CONFIG_FILE"
  fi
}

config_show() {
  printf 'Configuration file: %s (%s)\n' "$CONFIG_FILE" "$([[ $GRAB_CONFIG_LOADED == 1 ]] && printf loaded || printf defaults)"
  printf 'Storage:\n  primary=%s\n  sdcard=%s\n  termux=%s\n  default=%s\n' "$GRAB_STORAGE_PRIMARY" "$GRAB_STORAGE_SDCARD" "$GRAB_STORAGE_TERMUX" "$GRAB_STORAGE_DEFAULT"
  local k
  for k in GRAB_DEFAULT_DIR GRAB_DEST_VIDEO GRAB_DEST_AUDIO GRAB_DEST_IMAGE GRAB_DEST_DOCUMENT GRAB_DEST_PAGE GRAB_DEST_SITE GRAB_DEST_SCRIPT GRAB_DEST_ARCHIVE GRAB_CONNECT_TIMEOUT GRAB_TIMEOUT GRAB_RETRIES GRAB_RETRY_DELAY GRAB_MAX_RETRY_DELAY GRAB_USER_AGENT GRAB_COLLISION_POLICY GRAB_LOG_DIR GRAB_LOG_MAX_BYTES GRAB_LOG_LINES GRAB_MIRROR_DEPTH GRAB_MIRROR_RATE GRAB_MIRROR_DOMAINS GRAB_YTDLP_PATH GRAB_FFMPEG_PATH GRAB_WGET_PATH; do
    printf '%s=%q\n' "$k" "${!k}"
  done
  printf 'Precedence: command line > user config > built-in defaults\n'
}
