destination_for_type() {
  local type="$1" storage="${GRAB_STORAGE_DEFAULT:-primary}" root relative
  case "$type" in
    generic) relative="$GRAB_DEFAULT_DIR";;
    video) relative="$GRAB_DEST_VIDEO";;
    audio) relative="$GRAB_DEST_AUDIO";;
    image) relative="$GRAB_DEST_IMAGE";;
    document) relative="$GRAB_DEST_DOCUMENT";;
    page) relative="$GRAB_DEST_PAGE";;
    site) relative="$GRAB_DEST_SITE";;
    script) relative="$GRAB_DEST_SCRIPT";;
    archive) relative="$GRAB_DEST_ARCHIVE";;
    *) return 2;;
  esac
  [[ "$relative" == /* ]] && { printf '%s' "$relative"; return 0; }
  root="$(config_storage_root "$storage")" || return 2
  [[ -n "$root" ]] || {
    printf 'grab: microSD storage is not configured; edit %s\n' "$CONFIG_FILE" >&2
    return 73
  }
  printf '%s/%s' "${root%/}" "${relative#/}"
}

storage_available() {
  local storage="${1:-$GRAB_STORAGE_DEFAULT}" root
  root="$(config_storage_root "$storage")" || return 2
  [[ -n "$root" ]] || return 1
  [[ -d "$root" && -w "$root" ]]
}

ensure_destination() {
  local d="$1"
  if [[ ! -d "$d" ]]; then
    mkdir -p -- "$d" || { printf 'grab: cannot create destination: %s\n' "$d" >&2; return 1; }
  fi
  [[ -d "$d" && -w "$d" ]] || { printf 'grab: destination is not writable: %s\n' "$d" >&2; return 1; }
}

list_destinations() {
  printf '%-12s %s\n'     generic "$(destination_for_type generic)"     video "$(destination_for_type video)"     audio "$(destination_for_type audio)"     image "$(destination_for_type image)"     document "$(destination_for_type document)"     page "$(destination_for_type page)"     site "$(destination_for_type site)"     script "$(destination_for_type script)"     archive "$(destination_for_type archive)"
}
