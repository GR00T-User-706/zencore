download_generic() {
  local url="$1" type="$2" outdir="$3" explicit="$4" dry="$5" verbose="$6"
  local headers status effective disposition ctype name final tmpdir tmpfile statusfile effectivefile headerfile retries=0 rc=0
  ensure_destination "$outdir" || return 73
  if [[ "$dry" == 1 ]]; then printf 'DRY RUN: %s -> %s\n' "$(sanitize_url "$url")" "$outdir"; return 0; fi
  tmpdir=$(mktemp -d "$outdir/.grab.XXXXXX") || { printf 'grab: cannot create temporary directory in destination\n' >&2; return 73; }
  headerfile="$tmpdir/headers"; statusfile="$tmpdir/status"; effectivefile="$tmpdir/effective"; tmpfile="$tmpdir/payload"
  if [[ "$verbose" == 1 ]]; then printf 'grab: inspecting %s\n' "$(sanitize_url "$url")" >&2; fi
  # Probe metadata first, but tolerate servers that do not support HEAD.
  if http_probe "$url" headers status effective; then :; else headers=""; status=""; effective="$url"; fi
  disposition=$(printf '%s\n' "$headers" | awk 'tolower($0) ~ /^content-disposition:/ {sub(/^[^:]*:[[:space:]]*/, ""); sub(/\r$/, ""); value=$0} END{if (value != "") print value}')
  ctype=$(printf '%s\n' "$headers" | awk 'tolower($0) ~ /^content-type:/ {sub(/^[^:]*:[[:space:]]*/, ""); sub(/\r$/, ""); value=$0} END{if (value != "") print value}')
  name=$(choose_filename "$explicit" "$disposition" "${effective:-$url}" "$ctype" "$type")
  validate_name "$name" || { rm -rf -- "$tmpdir"; printf 'grab: invalid filename\n' >&2; return 2; }
  if [[ -n "${GRAB_OVERWRITE_TARGET:-}" && "$GRAB_OVERWRITE_TARGET" == "$outdir/$name" ]]; then
    final="$GRAB_OVERWRITE_TARGET"
  else
    final=$(unique_path "$outdir" "$name") || { rm -rf -- "$tmpdir"; return 73; }
  fi
  if [[ "$verbose" == 1 ]]; then printf 'grab: downloading to %s\n' "$final" >&2; fi
  if retries=$(http_download "$url" "$tmpfile" "$headerfile" "$statusfile" "$effectivefile"); then
    status=$(cat "$statusfile" 2>/dev/null || true); effective=$(cat "$effectivefile" 2>/dev/null || true)
    # Minimal HTML error-page sanity check for non-page categories.
    if [[ "$type" != page && "${ctype,,}" == application/octet-stream && -s "$tmpfile" ]]; then :; fi
    if [[ "$type" != page && -s "$tmpfile" ]] && head -c 256 "$tmpfile" | grep -Eiq '<!doctype[[:space:]]+html|<html([[:space:]>])'; then
      printf 'grab: response looks like HTML, not the requested file; preserving no output\n' >&2
      log_event ERROR "$type" "$url" "$outdir" "$name" "$status" 0 "$retries" failed 'unexpected HTML response'
      notify_download_failure "$name" 65 'unexpected HTML response'
      rm -rf -- "$tmpdir"; return 65
    fi
    mv -- "$tmpfile" "$final" || { rm -rf -- "$tmpdir"; return 74; }
    local bytes; bytes=$(wc -c < "$final" | tr -d ' ')
    if [[ "${GRAB_QUIET:-0}" != 1 ]]; then printf 'Downloaded: %s (%s bytes, HTTP %s)\n' "$final" "$bytes" "$status"; fi
    notify_download_success "$name" "$bytes" "$final"
    log_event INFO "$type" "$url" "$outdir" "$name" "$status" 0 "$retries" success "bytes=$bytes effective=$(sanitize_url "$effective")"
    rm -rf -- "$tmpdir"; return 0
  else
    rc=$?; status=$(cat "$statusfile" 2>/dev/null || true)
    log_event ERROR "$type" "$url" "$outdir" "$name" "$status" "$rc" "${retries:-0}" failed 'transfer failed'
    rm -rf -- "$tmpdir"; return "$rc"
  fi
}
