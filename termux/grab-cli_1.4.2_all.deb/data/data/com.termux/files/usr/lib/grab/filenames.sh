url_basename() {
  local url="$1" path base
  path="${url%%\#*}"; path="${path%%\?*}"; path="${path%/}"
  base="${path##*/}"
  if [[ -z "$base" ]]; then base=index.html; fi
  # Decode only common safe URL escapes; never decode encoded slash/backslash.
  base=${base//%20/ }; base=${base//%21/!}; base=${base//%28/(}; base=${base//%29/)}; base=${base//%27/\'}
  printf '%s' "$base"
}
content_type_extension() {
  local ct="${1,,}"; ct="${ct%%;*}"; ct="${ct//[[:space:]]/}"
  case "$ct" in
    image/jpeg) printf jpg;; image/png) printf png;; image/webp) printf webp;; image/gif) printf gif;; image/svg+xml) printf svg;; image/avif) printf avif;;
    application/pdf) printf pdf;; text/plain) printf txt;; text/html) printf html;; text/markdown|text/x-markdown) printf md;; text/csv) printf csv;; application/json|text/json) printf json;; application/xml|text/xml) printf xml;;
    application/epub+zip) printf epub;; application/zip) printf zip;; application/gzip) printf gz;; application/x-xz) printf xz;; application/x-tar) printf tar;;
    audio/mpeg) printf mp3;; audio/ogg) printf ogg;; audio/wav|audio/x-wav) printf wav;; video/mp4) printf mp4;; video/webm) printf webm;;
    application/vnd.openxmlformats-officedocument.wordprocessingml.document) printf docx;; application/vnd.openxmlformats-officedocument.spreadsheetml.sheet) printf xlsx;; application/vnd.openxmlformats-officedocument.presentationml.presentation) printf pptx;;
    *) return 1;;
  esac
}
sanitize_filename() {
  local n="$1"
  n="${n##*/}"; n="${n##*\\}"
  n="${n//$'\n'/}"; n="${n//$'\r'/}"; n="${n//$'\t'/ }"
  # Remove ASCII control characters and neutralize dot-only path components.
  n=$(printf '%s' "$n" | tr -d '\000-\037\177')
  [[ -n "$n" && "$n" != . && "$n" != .. ]] || n="download.bin"
  printf '%s' "$n"
}
choose_filename() {
  local explicit="$1" disposition="$2" url="$3" ctype="$4" type="$5" n=""
  if [[ -n "$explicit" ]]; then n="$explicit"
  elif [[ "$disposition" =~ filename\*?=[[:space:]]*\"?([^\"\;]+) ]]; then n="${BASH_REMATCH[1]}"
  else n=$(url_basename "$url"); fi
  n=$(sanitize_filename "$n")
  if [[ "$n" != *.* || "$n" == .* ]]; then
    local ext=""; ext=$(content_type_extension "$ctype" 2>/dev/null || true)
    if [[ -n "$ext" ]]; then n="$n.$ext"; fi
  fi
  # Don't invent a type-specific extension from the requested category.
  printf '%s' "$n"
}
unique_path() {
  local dir="$1" name="$2" stem ext i=1
  local candidate="$dir/$name"
  [[ ! -e "$candidate" ]] && { printf '%s' "$candidate"; return 0; }
  [[ "$GRAB_COLLISION_POLICY" != fail ]] || { printf 'grab: file already exists: %s\n' "$candidate" >&2; return 1; }
  if [[ "$name" == *.* && "$name" != .* ]]; then stem="${name%.*}"; ext=".${name##*.}"; else stem="$name"; ext=""; fi
  while [[ -e "$dir/${stem} ($i)${ext}" ]]; do ((i+=1)); done
  printf '%s' "$dir/${stem} ($i)${ext}"
}
