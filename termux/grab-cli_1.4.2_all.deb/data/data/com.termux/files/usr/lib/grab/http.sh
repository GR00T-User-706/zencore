http_probe() {
  local url="$1"; local -n out_headers="$2"; local -n out_status="$3"; local -n out_effective="$4"
  local tmp; tmp=$(mktemp) || return 1
  local -a args=(--silent --show-error --location --max-redirs 10 --connect-timeout "$GRAB_CONNECT_TIMEOUT" --max-time "$GRAB_TIMEOUT" --user-agent "$GRAB_USER_AGENT" --dump-header "$tmp" --output /dev/null --write-out $'\n%{http_code}\n%{url_effective}')
  local result rc=0; result=$(curl "${args[@]}" --head "$url" 2>/dev/null) || rc=$?
  # Some servers reject HEAD. GET one byte as a fallback.
  if (( rc != 0 )) || [[ "$(printf '%s' "$result" | tail -n 2 | head -n 1)" == 405 ]]; then
    result=$(curl --silent --show-error --location --max-redirs 10 --connect-timeout "$GRAB_CONNECT_TIMEOUT" --max-time "$GRAB_TIMEOUT" --user-agent "$GRAB_USER_AGENT" --range 0-0 --dump-header "$tmp" --output /dev/null --write-out $'\n%{http_code}\n%{url_effective}' "$url" 2>/dev/null) || rc=$?
  fi
  out_headers=$(cat "$tmp" 2>/dev/null || true); rm -f -- "$tmp"
  out_status=$(printf '%s\n' "$result" | tail -n 2 | head -n 1)
  out_effective=$(printf '%s\n' "$result" | tail -n 1)
  (( rc == 0 )) || return "$rc"
  [[ "$out_status" =~ ^[0-9]{3}$ ]] || return 1
  (( 10#$out_status >= 200 && 10#$out_status < 400 )) || return 22
}
http_download() {
  local url="$1" tmpfile="$2" headerfile="$3" statusfile="$4" effectivefile="$5" retries=0 rc=0 delay="$GRAB_RETRY_DELAY" status result
  local -a args=(--fail --silent --show-error --location --max-redirs 10 --connect-timeout "$GRAB_CONNECT_TIMEOUT" --max-time "$GRAB_TIMEOUT" --retry 0 --user-agent "$GRAB_USER_AGENT" --dump-header "$headerfile" --output "$tmpfile" --write-out $'\n%{http_code}\n%{url_effective}')
  while :; do
    result=$(curl "${args[@]}" "$url" 2>&1) && rc=0 || rc=$?
    status=$(printf '%s\n' "$result" | tail -n 2 | head -n 1)
    local effective; effective=$(printf '%s\n' "$result" | tail -n 1)
    printf '%s' "$status" > "$statusfile"; printf '%s' "$effective" > "$effectivefile"
    if (( rc == 0 )) && [[ "$status" =~ ^2[0-9][0-9]$ ]]; then printf '%s' "$retries"; return 0; fi
    # Retry transient network failures and selected HTTP statuses only.
    local retryable=0
    if (( rc == 5 || rc == 6 || rc == 7 || rc == 18 || rc == 28 || rc == 52 || rc == 55 || rc == 56 )); then retryable=1; fi
    if [[ "$status" == 429 || "$status" == 500 || "$status" == 502 || "$status" == 503 || "$status" == 504 ]]; then retryable=1; fi
    if (( ! retryable || retries >= GRAB_RETRIES )); then printf '%s\n' "$result" >&2; return "${rc:-1}"; fi
    ((retries+=1)); sleep "$delay"; (( delay < GRAB_MAX_RETRY_DELAY )) && delay=$((delay * 2)); (( delay > GRAB_MAX_RETRY_DELAY )) && delay="$GRAB_MAX_RETRY_DELAY"
  done
}
