handle_media() {
  local type="$1" url="$2" outdir="$3" explicit="$4" dry="$5" verbose="$6" force_direct="${7:-0}"
  if [[ "$type" == video || "$type" == audio ]] && [[ "$force_direct" != 1 ]]; then
    # Determine the extension from the URL path only. Signed URLs commonly
    # append query parameters after the media extension (for example .mp4?token=...).
    local pathpart="${url%%\#*}"
    pathpart="${pathpart%%\?*}"
    local lower="${pathpart,,}"
    if [[ "$lower" != *.mp4 && "$lower" != *.m4v && "$lower" != *.webm && "$lower" != *.mov && "$lower" != *.mkv && "$lower" != *.mp3 && "$lower" != *.m4a && "$lower" != *.ogg && "$lower" != *.opus && "$lower" != *.wav && "$lower" != *.flac && "$lower" != *.aac && "$lower" != *.oga && "$lower" != *.3gp && "$lower" != *.ts ]]; then
      if need_cmd "$GRAB_YTDLP_PATH"; then
        [[ "$dry" == 1 ]] && { printf 'DRY RUN: yt-dlp %s -> %s\n' "$(sanitize_url "$url")" "$outdir"; return 0; }
        ensure_destination "$outdir" || return 73
        local -a args=(--no-playlist --no-progress --output "$outdir/%(title).180B.%(ext)s")
        if [[ "$type" == audio ]]; then args+=(--extract-audio); fi
        args+=(-- "$url")
        "$GRAB_YTDLP_PATH" "${args[@]}" || { printf 'grab: yt-dlp failed; see its diagnostics above\n' >&2; notify_operation_failure "Media" "yt-dlp failed"; return 1; }
        log_event INFO "$type" "$url" "$outdir" "$explicit" '' '' 0 success 'yt-dlp completed'
        return 0
      fi
      printf 'grab: URL is not recognized as a direct media-file URL and yt-dlp is unavailable. Use --force-direct to attempt a direct curl download.\n' >&2
      return 69
    fi
  fi
  download_generic "$url" "$type" "$outdir" "$explicit" "$dry" "$verbose"
}
