termux_notify() {
  command -v termux-notification >/dev/null 2>&1 || return 0
  local title="$1" content="$2"
  termux-notification --title "$title" --content "$content" --priority high >/dev/null 2>&1 || true
}

notify_download_success() {
  local file="$1" bytes="$2" destination="$3"
  termux_notify "grab: Download finished" "${file} | ${bytes} bytes | ${destination}"
}

notify_download_failure() {
  local file="$1" rc="$2" reason="${3:-transfer failed}"
  termux_notify "grab: Download failed" "${file} | curl ${rc} | ${reason}"
}

notify_operation_success() {
  local title="$1" content="$2"
  termux_notify "grab: ${title}" "$content"
}

notify_operation_failure() {
  local title="$1" content="$2"
  termux_notify "grab: ${title} failed" "$content"
}
