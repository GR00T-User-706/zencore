handle_page() { download_generic "$1" page "$2" "${3:-}" "${4:-0}" "${5:-0}"; }
