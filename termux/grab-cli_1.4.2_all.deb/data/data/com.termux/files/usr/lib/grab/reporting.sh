print_help() {
cat <<'EOF'
GRAB - modular downloader for Termux
Usage: grab [TYPE] [OPTIONS] URL
       grab --help | --version | --check | --logs | --errors | --clear-logs
Types: --video --audio --image --document --page --site --script --archive --generic
Storage:
      --storage NAME         Storage root: internal, sdcard, or termux
      --internal-storage     Use Android internal storage (/storage/emulated/0)
      --sdcard               Use the configured microSD storage
      --termux-storage       Use Termux private storage ($HOME)
Options:
  -o, --output DIR       Destination directory (overrides storage/type destination)
  -f, --filename NAME    Explicit output filename
  -t, --type TYPE        Select type
  -q, --quiet            Suppress success message
  -v, --verbose          Verbose diagnostics
      --dry-run          Validate and show intended operation without downloading
      --overwrite        Permit replacing the explicit target filename
      --force-direct     For --video/--audio, skip yt-dlp and use curl directly
      --config           Create/edit the human-readable configuration file
      --config-show      Show effective configuration and sources
      --list-types       List supported types
      --list-destinations Show configured destinations
  -h, --help             Show help
      --version          Show version
      --check            Check runtime tools and storage readiness
      --logs              Show recent operational log entries
      --errors            Show recent error log entries
      --clear-logs       Clear only GRAB's own logs
Examples:
  grab 'https://example.org/archive.zip'
  grab --storage sdcard --image 'https://example.org/photo.webp'
  grab --termux-storage --script 'https://example.org/setup.sh'
  grab --page 'https://example.org/' --filename index.html
  grab --force-direct --video 'https://example.org/video?token=abc'
  grab -- 'https://example.org/file?download=1&token=abc'
Security: downloaded content is never executed. Inspect scripts before running them.
EOF
}
print_types() { printf '%s\n' generic video audio image document page site script archive; }
check_environment() {
  local failed=0
  for c in bash curl mktemp mv awk sed grep; do
    if command -v "$c" >/dev/null 2>&1; then printf 'OK   %s\n' "$c"; else printf 'MISS %s\n' "$c"; failed=1; fi
  done
  if [[ -d "$GRAB_STORAGE_PRIMARY" && -w "$GRAB_STORAGE_PRIMARY" ]]; then
    printf 'OK   Android internal storage: %s\n' "$GRAB_STORAGE_PRIMARY"
  else
    printf 'WARN Android internal storage unavailable: %s\n' "$GRAB_STORAGE_PRIMARY"
  fi
  if [[ -d "$GRAB_STORAGE_SDCARD" && -w "$GRAB_STORAGE_SDCARD" ]]; then
    printf 'OK   microSD storage: %s\n' "$GRAB_STORAGE_SDCARD"
  else
    printf 'INFO microSD storage unavailable: %s\n' "$GRAB_STORAGE_SDCARD"
  fi
  if [[ -d "$GRAB_STORAGE_TERMUX" && -w "$GRAB_STORAGE_TERMUX" ]]; then
    printf 'OK   Termux private storage: %s\n' "$GRAB_STORAGE_TERMUX"
  fi
  if command -v termux-notification >/dev/null 2>&1; then printf 'OK   optional termux-notification\n'; else printf 'INFO optional termux-notification not installed\n'; fi
  if command -v "$GRAB_YTDLP_PATH" >/dev/null 2>&1; then printf 'OK   optional yt-dlp\n'; else printf 'INFO optional yt-dlp not installed\n'; fi
  if command -v "$GRAB_FFMPEG_PATH" >/dev/null 2>&1; then printf 'OK   optional ffmpeg\n'; else printf 'INFO optional ffmpeg not installed\n'; fi
  if command -v "$GRAB_WGET_PATH" >/dev/null 2>&1; then printf 'OK   optional wget\n'; else printf 'INFO optional wget not installed\n'; fi
  return "$failed"
}
