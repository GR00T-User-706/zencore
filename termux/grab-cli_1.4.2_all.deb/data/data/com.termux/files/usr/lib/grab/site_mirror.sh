handle_site_mirror() {
  local url="$1" outdir="$2" dry="$3"
  need_cmd "$GRAB_WGET_PATH" || { printf 'grab: website mirroring requires wget. Install it with: pkg install wget\n' >&2; return 69; }
  ensure_destination "$outdir" || return 73
  local domain="${GRAB_MIRROR_DOMAINS:-}"
  if [[ -z "$domain" && "$url" =~ ^https?://([^/:]+) ]]; then domain="${BASH_REMATCH[1]}"; fi
  [[ -n "$domain" ]] || { printf 'grab: cannot determine mirror domain from URL\n' >&2; return 2; }
  if [[ "$dry" == 1 ]]; then printf 'DRY RUN: %s --mirror --level=%s --domains=%s -> %s\n' "$GRAB_WGET_PATH" "$GRAB_MIRROR_DEPTH" "$domain" "$(sanitize_url "$url")" "$outdir"; return 0; fi
  local -a args=(--mirror --level="$GRAB_MIRROR_DEPTH" --wait="$GRAB_MIRROR_RATE" --random-wait --no-parent --directory-prefix="$outdir" --domains="$domain" --execute robots=on --)
  "$GRAB_WGET_PATH" "${args[@]}" "$url" || { printf 'grab: website mirroring failed; inspect wget output and logs\n' >&2; log_event ERROR site "$url" "$outdir" '' '' '' 0 failed 'wget mirror failed'; notify_operation_failure "Site mirror" "wget mirror failed"; return 1; }
  log_event INFO site "$url" "$outdir" '' '' '' 0 success 'wget mirror completed; completeness is not guaranteed'
  notify_operation_success "Site mirror finished" "$domain -> $outdir"
}
