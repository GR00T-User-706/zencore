is_uint() { [[ "${1:-}" =~ ^[0-9]+$ ]]; }
validate_url() {
  local u="$1"
  [[ "$u" =~ ^https?://[^[:space:]]+$ ]] || { printf 'grab: URL must be an http:// or https:// URL with no whitespace\n' >&2; return 2; }
  [[ "$u" != *$'\n'* && "$u" != *$'\r'* ]] || return 2
}
validate_name() {
  local n="$1"
  [[ -n "$n" && "$n" != . && "$n" != .. && "$n" != */* && "$n" != *\\* && "$n" != *$'\n'* && "$n" != *$'\r'* ]] || return 1
  [[ "$n" != *$'\001'* ]] || return 1
}
need_cmd() { command -v -- "$1" >/dev/null 2>&1; }
