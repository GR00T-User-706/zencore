# Architecture

`bin/grab` loads modules relative to its own installation path. `arguments.sh` dispatches operations; `config.sh` establishes validated settings; `destinations.sh` resolves storage; `filenames.sh` handles names and MIME hints; `http.sh` centralizes curl; `downloader.sh` owns temporary files and finalization; specialized modules handle media, pages, and website mirroring; `logging.sh` and `reporting.sh` provide diagnostics. No downloaded content is executed.
