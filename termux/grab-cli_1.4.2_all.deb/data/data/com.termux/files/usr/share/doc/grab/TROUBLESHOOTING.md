# Troubleshooting

- **Shared storage missing:** run `termux-setup-storage`, then authorize access in Android if prompted.
- **Destination unwritable:** check the path and Android storage permission; GRAB does not silently redirect files.
- **Platform video URL unsupported:** install `yt-dlp` for supported platforms. DRM and access controls are not bypassed.
- **Website mirroring unavailable:** install `wget`; mirroring remains bounded and is not a guarantee of a complete offline copy.
- **Transfer fails:** inspect `grab --errors` and rerun with `--verbose`. Sensitive query parameters are omitted from logs.
- **Package build blocked:** set a verified maintainer name/email in `packaging/grab.yaml`, then use a Termux environment with a compatible `termux-create-package` version.
