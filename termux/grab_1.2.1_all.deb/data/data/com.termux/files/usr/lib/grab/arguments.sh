grab_main() {
  local type=generic url='' output='' filename='' quiet=0 verbose=0 dry=0 overwrite=0 force_direct=0 op='download' arg endopts=0 type_seen=0
  config_load || return 78
  log_init
  while (($#)); do
    arg="$1"; shift
    if (( ! endopts )); then
      case "$arg" in
        --) endopts=1; continue;;
        --help|-h) print_help; return 0;; --version) cat "${LIB_DIR%/lib/grab}/VERSION" 2>/dev/null || printf '0.1.0\n'; return 0;;
        --check) op=check; continue;; --logs) op=logs; continue;; --errors) op=errors; continue;; --clear-logs) op=clear-logs; continue;; --config) op=config; continue;; --list-types) op=types; continue;; --list-destinations) op=destinations; continue;;
        --video|--audio|--image|--document|--page|--site|--script|--archive|--generic)
          (( type_seen == 0 )) || { printf 'grab: conflicting or repeated type flags\n' >&2; return 2; }
          type="${arg#--}"; type_seen=1; continue;;
        --output|-o) (($#)) || { printf 'grab: %s requires a directory\n' "$arg" >&2; return 2; }; output="$1"; shift; continue;;
        --filename|-f) (($#)) || { printf 'grab: %s requires a filename\n' "$arg" >&2; return 2; }; filename="$1"; shift; continue;;
        --type|-t) (($#)) || { printf 'grab: %s requires a type\n' "$arg" >&2; return 2; }; type="$1"; type_seen=1; shift; continue;;
        --quiet|-q) quiet=1; continue;; --verbose|-v) verbose=1; continue;; --dry-run) dry=1; continue;; --overwrite) overwrite=1; continue;; --force-direct) force_direct=1; continue;;
        -*) printf 'grab: unknown option: %s\nUse --help for usage.\n' "$arg" >&2; return 2;;
      esac
    fi
    if [[ -z "$url" ]]; then url="$arg"; else printf 'grab: unexpected extra argument: %s\n' "$arg" >&2; return 2; fi
  done
  case "$op" in check) check_environment; return $?;; logs) show_logs all; return $?;; errors) show_logs errors; return $?;; clear-logs) clear_logs; return $?;; config) config_show; return $?;; types) print_types; return $?;; destinations) list_destinations; return $?;; esac
  [[ -n "$url" ]] || { printf 'grab: missing URL\nUse --help for usage.\n' >&2; return 2; }
  case "$type" in generic|video|audio|image|document|page|site|script|archive) ;; *) printf 'grab: unsupported type: %s\n' "$type" >&2; return 2;; esac
  validate_url "$url" || return 2
  if (( verbose && quiet )); then printf 'grab: --quiet and --verbose cannot be combined\n' >&2; return 2; fi
  if (( force_direct )) && [[ "$type" != video && "$type" != audio ]]; then
    printf 'grab: --force-direct requires --video or --audio\n' >&2
    return 2
  fi
  if [[ -n "$output" ]]; then
    [[ "$output" == /* ]] || output="$PWD/$output"
  else output=$(destination_for_type "$type"); fi
  if [[ -n "$filename" ]]; then validate_name "$filename" || { printf 'grab: filename must be a single safe path component\n' >&2; return 2; }; fi
  if (( overwrite )) && [[ -z "$filename" ]]; then printf 'grab: --overwrite requires --filename\n' >&2; return 2; fi
  # Overwrite is narrowly implemented for explicit names: back up target only in temp and restore on failure.
  if (( overwrite )) && [[ -e "$output/$filename" ]]; then
    printf 'grab: explicit overwrite requested for %s\n' "$output/$filename" >&2
    # Preserve target until transfer succeeds, then replace it during finalization.
    GRAB_OVERWRITE_TARGET="$output/$filename"
  else GRAB_OVERWRITE_TARGET=''; fi
  local rc=0
  GRAB_QUIET="$quiet"
  case "$type" in
    site) handle_site_mirror "$url" "$output" "$dry" || rc=$?;;
    video|audio) handle_media "$type" "$url" "$output" "$filename" "$dry" "$verbose" "$force_direct" || rc=$?;;
    page|generic|image|document|script|archive) download_generic "$url" "$type" "$output" "$filename" "$dry" "$verbose" || rc=$?;;
  esac
  if (( rc == 0 && quiet )); then :; fi
  return "$rc"
}
