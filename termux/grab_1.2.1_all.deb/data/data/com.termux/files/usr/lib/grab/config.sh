CONFIG_FILE="${GRAB_CONFIG_FILE:-${XDG_CONFIG_HOME:-$HOME/.config}/grab/grab.conf}"
config_defaults() {
  GRAB_DEFAULT_DIR="${HOME}/storage/shared/Download"
  GRAB_DEST_VIDEO="${HOME}/storage/shared/Movies"
  GRAB_DEST_AUDIO="${HOME}/storage/shared/Music"
  GRAB_DEST_IMAGE="${HOME}/storage/shared/Pictures"
  GRAB_DEST_DOCUMENT="${HOME}/storage/shared/Documents"
  GRAB_DEST_PAGE="${HOME}/storage/shared/Download/Pages"
  GRAB_DEST_SITE="${HOME}/storage/shared/Download/Sites"
  GRAB_DEST_SCRIPT="${HOME}/storage/shared/Download/Scripts"
  GRAB_DEST_ARCHIVE="${HOME}/storage/shared/Download/Archives"
  GRAB_CONNECT_TIMEOUT=20; GRAB_TIMEOUT=600; GRAB_RETRIES=2; GRAB_RETRY_DELAY=2; GRAB_MAX_RETRY_DELAY=20
  GRAB_USER_AGENT='grab/0.1.0 (Termux; curl)'; GRAB_COLLISION_POLICY=unique
  GRAB_LOG_DIR="${XDG_STATE_HOME:-$HOME/.local/state}/grab/logs"; GRAB_LOG_MAX_BYTES=1048576; GRAB_LOG_LINES=100
  GRAB_MIRROR_DEPTH=2; GRAB_MIRROR_RATE=1; GRAB_MIRROR_DOMAINS=
  GRAB_YTDLP_PATH=yt-dlp; GRAB_FFMPEG_PATH=ffmpeg; GRAB_WGET_PATH=wget
  GRAB_CONFIG_LOADED=0
}
config_validate() {
  local key val
  for key in GRAB_CONNECT_TIMEOUT GRAB_TIMEOUT GRAB_RETRIES GRAB_RETRY_DELAY GRAB_MAX_RETRY_DELAY GRAB_LOG_MAX_BYTES GRAB_LOG_LINES GRAB_MIRROR_DEPTH GRAB_MIRROR_RATE; do
    val="${!key}"
    is_uint "$val" || { printf 'grab: invalid config value %s=%s\n' "$key" "$val" >&2; return 2; }
  done
  (( GRAB_CONNECT_TIMEOUT > 0 && GRAB_TIMEOUT > 0 && GRAB_RETRIES <= 10 && GRAB_MIRROR_DEPTH <= 10 && GRAB_MIRROR_RATE > 0 )) || { printf 'grab: config numeric value out of range\n' >&2; return 2; }
  [[ "$GRAB_COLLISION_POLICY" == unique || "$GRAB_COLLISION_POLICY" == fail ]] || { printf 'grab: GRAB_COLLISION_POLICY must be unique or fail\n' >&2; return 2; }
  local d; for d in "$GRAB_DEFAULT_DIR" "$GRAB_DEST_VIDEO" "$GRAB_DEST_AUDIO" "$GRAB_DEST_IMAGE" "$GRAB_DEST_DOCUMENT" "$GRAB_DEST_PAGE" "$GRAB_DEST_SITE" "$GRAB_DEST_SCRIPT" "$GRAB_DEST_ARCHIVE" "$GRAB_LOG_DIR"; do
    [[ "$d" == /* ]] || { printf 'grab: configured paths must be absolute: %s\n' "$d" >&2; return 2; }
  done
}
config_load() {
  config_defaults
  if [[ -f "$CONFIG_FILE" ]]; then
    # This is intentionally a trusted shell config; never point it at downloaded files.
    # shellcheck source=/dev/null
    source "$CONFIG_FILE"
    GRAB_CONFIG_LOADED=1
  fi
  config_validate
}
config_show() {
  printf 'Configuration file: %s (%s)\n' "$CONFIG_FILE" "$([[ $GRAB_CONFIG_LOADED == 1 ]] && printf loaded || printf defaults)"
  local k; for k in GRAB_DEFAULT_DIR GRAB_DEST_VIDEO GRAB_DEST_AUDIO GRAB_DEST_IMAGE GRAB_DEST_DOCUMENT GRAB_DEST_PAGE GRAB_DEST_SITE GRAB_DEST_SCRIPT GRAB_DEST_ARCHIVE GRAB_CONNECT_TIMEOUT GRAB_TIMEOUT GRAB_RETRIES GRAB_RETRY_DELAY GRAB_MAX_RETRY_DELAY GRAB_USER_AGENT GRAB_COLLISION_POLICY GRAB_LOG_DIR GRAB_LOG_MAX_BYTES GRAB_LOG_LINES GRAB_MIRROR_DEPTH GRAB_MIRROR_RATE GRAB_MIRROR_DOMAINS GRAB_YTDLP_PATH GRAB_FFMPEG_PATH GRAB_WGET_PATH; do printf '%s=%q\n' "$k" "${!k}"; done
  printf 'Precedence: command line > user config > built-in defaults\n'
}
