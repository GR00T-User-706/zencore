destination_for_type() {
  case "$1" in
    generic) printf '%s' "$GRAB_DEFAULT_DIR";; video) printf '%s' "$GRAB_DEST_VIDEO";; audio) printf '%s' "$GRAB_DEST_AUDIO";; image) printf '%s' "$GRAB_DEST_IMAGE";; document) printf '%s' "$GRAB_DEST_DOCUMENT";; page) printf '%s' "$GRAB_DEST_PAGE";; site) printf '%s' "$GRAB_DEST_SITE";; script) printf '%s' "$GRAB_DEST_SCRIPT";; archive) printf '%s' "$GRAB_DEST_ARCHIVE";; *) return 2;;
  esac
}
ensure_destination() {
  local d="$1"
  if [[ "$d" == "$HOME/storage/shared"* && ! -e "$HOME/storage/shared" ]]; then
    printf 'grab: Termux shared storage is unavailable. Run: termux-setup-storage\n' >&2; return 1
  fi
  if [[ ! -d "$d" ]]; then mkdir -p -- "$d" || { printf 'grab: cannot create destination: %s\n' "$d" >&2; return 1; }; fi
  [[ -d "$d" && -w "$d" ]] || { printf 'grab: destination is not writable: %s\n' "$d" >&2; return 1; }
}
list_destinations() {
  printf '%-12s %s\n' generic "$GRAB_DEFAULT_DIR" video "$GRAB_DEST_VIDEO" audio "$GRAB_DEST_AUDIO" image "$GRAB_DEST_IMAGE" document "$GRAB_DEST_DOCUMENT" page "$GRAB_DEST_PAGE" site "$GRAB_DEST_SITE" script "$GRAB_DEST_SCRIPT" archive "$GRAB_DEST_ARCHIVE"
}
