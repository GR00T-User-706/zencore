# Logging primitives. Logs are best-effort and never replace the operation's status.
GRAB_LOG_FAILURE=0
log_init() {
  local base="${GRAB_LOG_DIR:-${XDG_STATE_HOME:-$HOME/.local/state}/grab/logs}"
  GRAB_LOG_DIR=$base
  GRAB_OP_LOG="$base/grab.log"
  GRAB_ERR_LOG="$base/errors.log"
  if ! mkdir -p -- "$base" 2>/dev/null; then GRAB_LOG_FAILURE=1; return 0; fi
  chmod 700 -- "$base" 2>/dev/null || true
  log_rotate "$GRAB_OP_LOG"; log_rotate "$GRAB_ERR_LOG"
}
log_rotate() {
  local f="$1" limit="${GRAB_LOG_MAX_BYTES:-1048576}"
  [[ -f "$f" ]] || return 0
  local size; size=$(wc -c < "$f" 2>/dev/null || printf '0')
  if [[ "$size" =~ ^[0-9]+$ ]] && (( size >= limit )); then
    mv -f -- "$f" "$f.1" 2>/dev/null || GRAB_LOG_FAILURE=1
  fi
}
sanitize_url() {
  local u="$1"
  # Strip userinfo and query/fragment to avoid leaking tokens and private parameters.
  u="${u%%\#*}"; u="${u%%\?*}"
  if [[ "$u" =~ ^([a-zA-Z][a-zA-Z0-9+.-]*://)([^/@]+@)?(.*)$ ]]; then u="${BASH_REMATCH[1]}${BASH_REMATCH[3]}"; fi
  printf '%s' "$u"
}
log_event() {
  local level="$1" op="$2" url="$3" dest="$4" file="$5" status="$6" curlcode="$7" retries="$8" result="$9" message="${10:-}"
  local ts line safeurl
  ts=$(date '+%Y-%m-%dT%H:%M:%S%:z' 2>/dev/null || date)
  safeurl=$(sanitize_url "$url")
  # Tab-separated fields; remove controls to preserve one record per line.
  message=${message//$'\n'/ }; message=${message//$'\r'/ }
  line=$(printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$ts" "$level" "$op" "$safeurl" "$dest" "$file" "$status" "$curlcode" "$retries" "$result: $message")
  if (( ! GRAB_LOG_FAILURE )); then
    printf '%s\n' "$line" >> "$GRAB_OP_LOG" 2>/dev/null || GRAB_LOG_FAILURE=1
    if [[ "$level" == ERROR || "$level" == FATAL ]]; then printf '%s/n' "$line" >> "$GRAB_ERR_LOG" 2>/dev/null || GRAB_LOG_FAILURE=1; fi
  fi
}
show_logs() {
  local mode="${1:-all}" file
  if [[ ! -d "${GRAB_LOG_DIR:-${XDG_STATE_HOME:-$HOME/.local/state}/grab/logs}" ]]; then printf 'grab: no logs found\n' >&2; return 1; fi
  if [[ "$mode" == errors ]]; then file="$GRAB_ERR_LOG"; else file="$GRAB_OP_LOG"; fi
  [[ -f "$file" ]] || { printf 'grab: no %s log entries\n' "$mode"; return 0; }
  tail -n "${GRAB_LOG_LINES:-100}" -- "$file"
}
clear_logs() {
  local d="$GRAB_LOG_DIR"
  [[ "$d" == /* && "$d" != / && "$d" != "$HOME" ]] || { printf 'grab: refusing unsafe log path: %s\n' "$d" >&2; return 1; }
  rm -f -- "$d/grab.log" "$d/grab.log.1" "$d/errors.log" "$d/errors.log.1"
}
