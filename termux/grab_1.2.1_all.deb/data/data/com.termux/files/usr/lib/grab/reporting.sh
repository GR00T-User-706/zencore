print_help() {
cat <<'EOF'
GRAB - modular downloader for Termux
Usage: grab [TYPE] [OPTIONS] URL
       grab --help | --version | --check | --logs | --errors | --clear-logs
Types: --video --audio --image --document --page --site --script --archive --generic
Options:
  -o, --output DIR       Destination directory
  -f, --filename NAME    Explicit output filename
  -t, --type TYPE        Select type (generic, video, audio, image, document, page, site, script, archive)
  -q, --quiet            Suppress success message
  -v, --verbose          Verbose diagnostics
      --dry-run          Validate and show intended operation without downloading
      --overwrite        Permit replacing the explicit target filename
      --force-direct     For --video/--audio, skip yt-dlp and use curl directly
      --config           Show effective configuration and sources
      --list-types       List supported types
      --list-destinations Show configured destinations
  -h, --help             Show help
      --version          Show version
      --check            Check runtime tools and storage readiness
      --logs             Show recent operational log entries
      --errors           Show recent error log entries
      --clear-logs       Clear only GRAB's own logs
Examples:
  grab 'https://example.org/archive.zip'
  grab --image 'https://example.org/photo.webp' --output "$HOME/storage/shared/Pictures"
  grab --page 'https://example.org/' --filename index.html
  grab --dry-run --script 'https://example.org/setup.sh'
  grab --force-direct --video 'https://example.org/video?token=abc'
  grab -- 'https://example.org/file?download=1&token=abc'
Security: downloaded content is never executed. Inspect scripts before running them.
EOF
}
print_types() { printf '%s\n' generic video audio image document page site script archive; }
check_environment() {
  local failed=0
  for c in bash curl mktemp mv awk sed grep; do if command -v "$c" >/dev/null 2>&1; then printf 'OK   %s\n' "$c"; else printf 'MISS %s\n' "$c"; failed=1; fi; done
  if [[ -e "$HOME/storage/shared" && -w "$HOME/storage/shared" ]]; then printf 'OK   shared storage link\n'; else printf 'WARN shared storage unavailable; run termux-setup-storage\n'; fi
  if command -v "$GRAB_YTDLP_PATH" >/dev/null 2>&1; then printf 'OK   optional yt-dlp\n'; else printf 'INFO optional yt-dlp not installed\n'; fi
  if command -v "$GRAB_FFMPEG_PATH" >/dev/null 2>&1; then printf 'OK   optional ffmpeg\n'; else printf 'INFO optional ffmpeg not installed\n'; fi
  if command -v "$GRAB_WGET_PATH" >/dev/null 2>&1; then printf 'OK   optional wget\n'; else printf 'INFO optional wget not installed\n'; fi
  return "$failed"
}
