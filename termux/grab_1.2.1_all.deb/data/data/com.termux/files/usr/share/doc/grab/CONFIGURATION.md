# Configuration

Copy `config/grab.conf.example` to `~/.config/grab/grab.conf`. It is trusted shell configuration and is sourced by Bash; never use a downloaded or untrusted file. CLI options override config values, which override built-in defaults. Numeric values and destination paths are validated at startup.

The configuration supports destination paths, connection and overall timeouts, bounded retries, user-agent, collision policy, log path/size/line count, optional executable names, and website mirror depth/rate/domain settings. `grab --config` prints effective values and their source state.
