# GRAB

GRAB is a modular Bash downloader designed for Termux on Android. It uses `curl` for direct HTTP/HTTPS downloads and supports category-specific destinations, filename collision avoidance, logs, configuration, dry runs, and optional `yt-dlp`/`wget` integrations.

## Requirements

- Termux with Bash and curl; no root or desktop environment required.
- Android shared-storage access for default shared destinations. Run `termux-setup-storage`.
- Optional: `yt-dlp` for supported media platform extraction; `wget` for website mirroring; `ffmpeg` is not required by the current implementation.

## Build and install

Use a Termux build environment with `termux-create-package`. From the project root, build the package directly with `termux-create-package ./packaging/grab.yaml`. Then install the generated `grab_0.1.0_all.deb` with `apt install ./grab_0.1.0_all.deb`.

## Quick start

```bash
grab 'https://example.org/file.zip'
grab --video 'https://example.org/video.mp4'
grab --force-direct --video 'https://example.org/video?token=abc'
grab --page 'https://example.org/' --filename index.html
grab --dry-run --archive 'https://example.org/archive.tar.xz'
grab --check
grab --logs
grab --errors
```

See [Usage](docs/USAGE.md), [Configuration](docs/CONFIGURATION.md), [Troubleshooting](docs/TROUBLESHOOTING.md), and [Architecture](docs/ARCHITECTURE.md). A man page is provided as `man/grab.1`.

## Destinations

Generic: `Download`; video: `Movies`; audio: `Music`; images: `Pictures`; documents: `Documents`; pages: `Download/Pages`; mirrors: `Download/Sites`; scripts: `Download/Scripts`; archives: `Download/Archives`. Paths are configurable.

## Logs and configuration

Configuration: `~/.config/grab/grab.conf`. Logs default to `~/.local/state/grab/logs/`. Logs rotate at the configured size limit. Use `grab --clear-logs` to clear only GRAB's own current and rotated log files.

## Security and limitations

Downloaded scripts are never executed and files are not automatically extracted. Do not run scripts or open downloaded files without inspecting them. HTTP status and metadata do not prove content is safe. Direct `curl` downloads do not extract streaming platforms. For video/audio URLs not recognized as direct files, extraction depends on `yt-dlp` and the platform's permitted access. Use `--force-direct` with `--video` or `--audio` to skip `yt-dlp` and attempt a direct `curl` download, including for signed URLs without a recognizable extension. Website mirroring depends on `wget`, respects robots.txt, uses configured bounds, and cannot guarantee complete mirroring. TLS verification remains enabled by default.

## Testing

Run `tests/run-tests.sh`. Use ShellCheck when available. Local HTTP integration, actual package building, clean installation, and uninstall tests must be performed in a compatible Termux environment; results must not be inferred from syntax checks alone.

## Exit status

The CLI uses conventional nonzero statuses for usage, unavailable dependency, transfer, permission, and configuration failures. Exact curl status codes may be returned for transfer failures; inspect stderr and logs for details.

## Version and license

Version: 0.1.0. License selection is pending maintainer approval; no license grant is implied by this source archive.
