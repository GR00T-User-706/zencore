# GRAB Usage

```bash
grab [TYPE] [OPTIONS] URL
grab --help
grab --check
grab --logs
```

Types: `--generic`, `--video`, `--audio`, `--image`, `--document`, `--page`, `--site`, `--script`, `--archive`. The default is generic. Use one type selector only.

Examples:

```bash
grab 'https://example.org/archive.zip'
grab --image 'https://example.org/photo.webp' --output "$HOME/storage/shared/Pictures"
grab --page 'https://example.org/' --filename index.html
grab --dry-run --script 'https://example.org/setup.sh'
grab -- 'https://example.org/file?download=1&token=abc'
```

Use `--force-direct` with `--video` or `--audio` to bypass `yt-dlp` and attempt a direct `curl` download. GRAB recognizes media extensions in the URL path even when the URL has query parameters, such as signed download tokens. The original URL is preserved for the request.

The `--output` value is a directory. `--filename` is a single filename, not a path. Existing files receive a numbered suffix by default. `--overwrite` requires `--filename`; note that explicit overwrite handling must be verified in the installed build before relying on it.
