# GRABITUI

GRABITUI is the terminal user interface for GRAB. It is deliberately a frontend, not a second downloader.

The TUI depends on the `grab-cli` package and invokes the existing `grab` command for downloads, destination resolution, configuration, diagnostics, and logs.

## Launch

```bash
grabitui
```

The New Download screen collects:

- download type
- storage root: Android internal, microSD, or Termux private storage
- URL
- optional filename
- optional explicit output directory

Android internal storage is the default storage root. The microSD mount path remains configurable in GRAB's configuration.

GRABITUI does not replace CLI functionality. Scripts and automation should continue using `grab` directly.
