# GRABITUI

GRABITUI is the Textual terminal user interface for GRAB. It is a frontend, not a second downloader.

The grabitui package depends on grab-cli and invokes the existing grab command for downloads, destination resolution, configuration, diagnostics, and logs.

## Requirements

- Python 3.9 or newer.
- Textual installed in the target Python environment.

Install Textual from PyPI if it is not already available:

```bash
python -m pip install textual
```

Textual's upstream documentation requires Python 3.9 or newer and documents installation from PyPI.

## Launch

```bash
grabitui
```

## Navigation

The main menu provides:

- New Download
- Destinations
- Configuration
- Diagnostics
- Logs
- Quit

Secondary screens provide a Back action and support Escape for navigation. New Download is a dedicated form rather than a sequence of terminal prompts.

## New Download

The download form collects:

- download type
- storage root
- URL
- optional filename
- optional explicit output directory

GRABITUI passes those choices to grab. It does not implement a separate downloader.

## Storage

Android internal storage is the default root. The microSD root must be configured by the user because removable-storage mount identifiers are device-specific. Termux private storage uses the current user's home directory.

## Configuration

Configuration editing is delegated to grab --config, so GRAB's CLI remains the authority for configuration-file creation and editor selection.

## CLI boundary

Scripts and automation should continue using grab directly. GRABITUI is an interactive frontend and does not replace the CLI.
