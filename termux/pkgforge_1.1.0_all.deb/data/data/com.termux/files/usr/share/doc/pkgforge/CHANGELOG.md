# Changelog

All notable changes to pkgForge are documented here.

This changelog records changes to the pkgForge project itself. Versions of packages built by pkgForge are recorded in those projects' own changelogs.

## [1.1.0] - 2026-11-01

### Added
- Implement native Arch Linux package builds through makepkg, with pacman metadata and file-list inspection plus bsdtar archive validation.
- Generate pacman install scripts, ALPM transaction hooks, package handling notes, and .SRCINFO.
- Add Arch package metadata for optional dependencies, conflicts, provides, replacements, groups, backup configuration paths, source checksums, and build phases.
- Exclude common Python bytecode/cache, VCS, virtual-environment, and build-output debris from Arch payload staging.
- Add a self-hosting Arch package manifest that builds and installs the pkgForge Python wheel.
- Add and package a pkgForge section-1 manual page.
- Compile pkgForge bytecode inside Arch package staging so pacman tracks and removes the generated .pyc files.
- Document package lifecycle ownership, maintainer scripts, configuration preservation, triggers, man pages, and service integration.

### Fixed
- Keep package-owned file removal under native package-manager control; no generated uninstall hook deletes package files or user data.
- Require Arch builds to run as an unprivileged user and avoid dependency installation or package installation during builds.

### Validation
- Add mocked native-tool tests for Arch build orchestration, metadata inspection, payload exclusions, and lifecycle generation.
- Real Arch makepkg execution, package installation, and removal are verified in the Arch Linux CI container.

## [1.0.0] - 2026-11-01

### Changed
- Establish pkgForge as an independently usable packaging engine, with version lifecycle responsibilities kept outside the package manifest and CLI.
- Preserve optional legacy VERSIONING manifest metadata for schema v1 compatibility without invoking or depending on a version-management engine.

### Fixed
- Reject payload symlinks that resolve outside FILES_DIR while preserving safe in-root symlinks.
- Exclude the build output directory from directory payload copies and stage temporary build workspaces outside the payload tree.
- Apply FIX_PERMISSIONS during Debian payload staging, defaulting to normalized package permissions.
- Preserve supported Debian maintainer scripts and control files in the DEBIAN control directory.
- Reject symlinked Debian maintainer/control files.

### Added
- Add regression coverage for payload symlink escapes, recursive output inclusion, permission normalization, and maintainer-file preservation.

## [0.2.0] - 2026-10-25

### Changed
- Separate conventional Debian builds from Termux builds: Debian uses `dpkg-deb --build`, while Termux uses `termux-create-package`.
- Remove version lifecycle commands and SemVer Forge integration from pkgForge so it remains an independent packaging engine.
- Remove release/version-engine settings from the canonical packaging manifest.

### Fixed
- Correct Debian and Termux native toolchain reporting.
- Validate payload sources before invoking either native build path.
- Report both supported Debian-family build profiles accurately.

### Added
- Add focused tests for conventional Debian build staging, native tool invocation, toolchain detection, and artifact collision refusal.
- Add a real `dpkg-deb` package-build and archive-inspection integration test for CI.

### Documentation
- Clarify the independent responsibilities of packaging and version-management engines.
- Correct backend capability and native build documentation.

## [0.1.0] - 2026-10-23

### Added
- Initial canonical JSON manifest, versioned schema, and semantic validation.
- Extensible backend registry and generators for Debian, Arch, RPM, and AppImage.
- Initial Debian-family native build orchestration and artifact inspection.
- Initial companion version adapter, subsequently removed when the engine boundaries were formalized.
- Documentation for manifest structure, architecture, plugins, and version policy.

### Changed
- Established explicit separation between metadata generation, native package builds, artifact inspection, and release/version operations.

### Documentation
- Added repository-wide agent instructions and the pkgForge versioning policy.
