# pkgForge

**pkgForge** is an independent, extensible software packaging engine. It validates one canonical JSON project manifest, generates native packaging definitions, invokes supported native package builders, and inspects the resulting artifacts.

pkgForge is deliberately separate from version-management and release automation. Its job is to package the version already declared by the project manifest, not calculate versions, manage changelogs, create releases, or synchronize version files. A higher-level tool can coordinate pkgForge with a separate version engine without making either engine dependent on the other.

## Design principles

- Canonical, versioned JSON metadata with `UPPERCASE_SNAKE_CASE` keys.
- Native packaging tools remain responsible for native artifacts.
- Manifest validation, definition generation, package building, and artifact inspection are distinct operations.
- No automatic package installation or execution of generated recipes.
- No silent overwrites of existing generated files or artifacts.
- Backends are independent modules behind a documented plugin interface.
- Preserve existing project layouts unless explicitly asked to change them.

## Quick start

Requires Python 3.11 or newer.

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -e '.[dev]'
pkgforge init ./example-project/pkgforge.json
pkgforge validate ./example-project/pkgforge.json
pkgforge backends
pkgforge generate ./example-project/pkgforge.json --backend debian --output ./generated
pkgforge doctor --backend debian
pkgforge validate examples/debian.pkgforge.json
pkgforge build examples/debian.pkgforge.json --backend debian --output ./dist
pkgforge validate examples/pkgforge-self.pkgforge.json
# On Arch Linux, as an unprivileged user:
pkgforge doctor --backend arch
pkgforge build examples/pkgforge-self.pkgforge.json --backend arch --output ./dist
```

See [docs/manifest.md](docs/manifest.md), the [package lifecycle guide](docs/package-lifecycle.md), [the v1 schema](schema/pkgforge-v1.schema.json), [the starter manifest](examples/minimal.pkgforge.json), the [buildable Debian example](examples/debian.pkgforge.json), and the [pkgForge self-hosting Arch manifest](examples/pkgforge-self.pkgforge.json). Third-party backend authors can use the [plugin contract](docs/plugins.md).

## Backend implementation status

| Backend | Definition generation | Native build |
|---|---|---|
| Debian / Termux | Debian control metadata and Termux builder manifest | Native `.deb` builds supported through `dpkg-deb` (Debian profile) and `termux-create-package` (Termux profile) |
| Arch Linux | `PKGBUILD`, pacman install script, ALPM hooks, package notes, `.SRCINFO` | Native `makepkg` build and artifact inspection |
| RPM | Starter spec file | Not implemented |
| AppImage | AppDir and AppRun scaffold | Not implemented |
| Flatpak, Snap, Alpine, Python distributions, Windows, macOS, BSD, OCI | Planned | Not implemented |

The Debian backend exposes two profiles and uses different native build paths. Debian stages the payload and control metadata into a temporary package root, then invokes `dpkg-deb --build`. Termux invokes the official `termux-create-package` utility. Both paths inspect the resulting archive with `dpkg-deb`. The Debian profile is exercised with a real `dpkg-deb` build in Ubuntu CI. Arch is also exercised in a real Arch Linux base-devel container: CI builds pkgForge with makepkg, installs it with pacman, checks the CLI/manual page, and removes it with pacman. Broader Debian release coverage and a real Termux environment build also remain outstanding. Mocked Termux subprocess tests validate orchestration, not compatibility with every Termux toolchain version.

## Commands

- `pkgforge init PATH`: create an example manifest without overwriting.
- `pkgforge validate MANIFEST`: validate the manifest and schema.
- `pkgforge inspect MANIFEST`: print a concise project summary.
- `pkgforge backends`: list generation and build capabilities.
- `pkgforge doctor [--backend NAME] [--profile debian|termux]`: detect native tools without executing them.
- `pkgforge generate MANIFEST --backend NAME --output DIR`: generate native definition files without running them.
- `pkgforge build MANIFEST --backend debian --output DIR`: build and inspect a Debian-family package.
- `pkgforge build MANIFEST --backend arch --output DIR`: build and inspect an Arch package using makepkg (must run as an unprivileged user).

Use `pkgforge COMMAND --help` for details.


## Arch Linux packages and lifecycle handling

The Arch backend generates a native PKGBUILD, an optional package .install script, optional ALPM transaction hooks under hooks/, and PACKAGE-NOTES.md. Native builds also retain .SRCINFO in the output directory. The self-hosting pkgForge package also installs the pkgforge(1) manual page under /usr/share/man/man1. The builder requires makepkg, pacman, and bsdtar; it refuses to run as root, does not install dependencies, does not install the resulting package, and validates package metadata and declared payload paths before returning the artifact.

Example target configuration:

```json
{
  "TARGETS": {
    "ARCH": {
      "ENABLED": true,
      "PACKAGE_NAME": "exampleapp",
      "ARCHITECTURE": "any",
      "RELEASE": "1",
      "DEPENDS": ["python"],
      "MAKEDEPENDS": ["python-build"],
      "BACKUP": ["etc/exampleapp.conf"],
      "DATA_FILES": [
        {"SOURCE": "bin/example", "DESTINATION": "usr/bin/example"}
      ],
      "INSTALL_HOOKS": {
        "POST_INSTALL": ["systemctl daemon-reload"]
      }
    }
  }
}
```

Pacman owns installed package files. Use BACKUP for configuration preservation, install scripts for necessary transaction actions, and ALPM hooks for transaction-triggered maintenance. Do not manually delete package-owned files or user data from removal hooks. Common caches and bytecode are excluded from Arch payload staging by default; additional patterns belong in TARGETS.ARCH.EXCLUDE. See the package lifecycle guide for Debian maintainer scripts, dpkg triggers, Arch hooks, configuration handling, man pages, and service integration.

## Debian and Termux payloads

Set `TARGETS.DEBIAN.PROFILE` to `debian` or `termux`. The default is `debian`.

- `PACKAGE_NAME`: optional native package name.
- `ARCHITECTURE`: package architecture. Termux accepts `all`, `arm`, `i686`, `aarch64`, or `x86_64`.
- `INSTALLATION_PREFIX`: defaults to `/usr` for Debian and `/data/data/com.termux/files/usr` for Termux. Termux's prefix is enforced.
- `FILES_DIR`: payload root, relative to the manifest directory unless absolute.
- `DATA_FILES`: explicit `SOURCE` and `DESTINATION` mappings. Source paths must resolve inside `FILES_DIR`; destinations are relative to the installation prefix. `FIX_PERMISSIONS` defaults to `true` and normalizes directories/executables to `0755` and regular files to `0644`.
- `DEPENDENCY_MAP`: explicit mapping from canonical runtime dependency identifiers to native package names.

Example:

```json
{
  "TARGETS": {
    "DEBIAN": {
      "ENABLED": true,
      "PROFILE": "debian",
      "ARCHITECTURE": "all",
      "FILES_DIR": "package-files",
      "DEPENDENCY_MAP": [
        {"DEPENDENCY": "python", "PACKAGE": "python3"}
      ],
      "DATA_FILES": [
        {"SOURCE": "bin/my-tool", "DESTINATION": "bin/my-tool"},
        {"SOURCE": "share/my-tool/config.json", "DESTINATION": "share/my-tool/config.json"}
      ]
    }
  }
}
```

## Development

```sh
python -m pip install -e '.[dev]'
pytest
ruff check .
mypy src
```

Generation writes text definitions only. The native build paths support Debian/Termux `.deb` packages and Arch `.pkg.tar.*` packages. RPM and AppImage remain generators only. Debian builds reject payload symlinks escaping `FILES_DIR`, preserve in-root symlinks, exclude the output directory from recursive payload copies, preserve supported maintainer/control files, use bounded native-tool timeouts, refuse to overwrite existing artifacts, and never install the resulting package. Review generated recipes before using them. Project licensing has not yet been selected; do not assume a license until one is explicitly added.
